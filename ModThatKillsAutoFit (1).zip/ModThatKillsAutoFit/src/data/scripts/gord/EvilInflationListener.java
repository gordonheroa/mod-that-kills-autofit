package data.scripts.gord;

import java.util.List;
import java.lang.reflect.Method;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.BoundsAPI.SegmentAPI;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatFleetManagerAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI.SystemState;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.loading.WeaponSlotAPI;
import com.fs.starfarer.api.util.CountingMap;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.SettingsAPI;
import com.fs.starfarer.api.plugins.impl.CoreAutofitPlugin;
import com.fs.starfarer.api.plugins.AutofitPlugin;
import com.fs.starfarer.api.plugins.AutofitPlugin.AutofitPluginDelegate;

import com.fs.starfarer.api.campaign.FleetInflater;
import com.fs.starfarer.api.campaign.listeners.FleetInflationListener;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;

public class EvilInflationListener implements FleetInflationListener {
    @Override 
    public void reportFleetInflated(CampaignFleetAPI fleet, FleetInflater inflater) {
        if (fleet.isPlayerFleet()) return;
        int unusedOP = 0;
        CoreAutofitPlugin fitter = new CoreAutofitPlugin(fleet.getCommander());
        for(com.fs.starfarer.api.fleet.FleetMemberAPI member : fleet.getMembersWithFightersCopy()) {
            if(Global.getSettings().getVariant(member.getVariant().getOriginalVariant()) == null) {
                continue;
            }
            int smods = member.getVariant().getSMods().size();
            if(!member.isFighterWing()) {
                member.setVariant(Global.getSettings().getVariant(member.getVariant().getOriginalVariant()).clone(),false,false);
            } else {
                continue;
            }
            smods -= member.getVariant().getSMods().size();
            unusedOP += addSMod(member,"autorepair",smods);
            smods -= 1;
            if(smods > 0) {
                if(member.getVariant().hasHullMod("magazines")) {
                    member.getVariant().removeMod("magazines");
                    unusedOP += returnCost("magazines",member.getHullSpec().getHullSize());
                    smods -= 1;
                }
            }
            unusedOP += addSMod(member,"reinforcedhull",smods);
            smods -= 1;
            unusedOP += addSMod(member,"fluxdistributor",smods);
            smods -= 1;
            unusedOP += addSMod(member,"turretgyros",smods);
            smods -= 1;
            unusedOP += addSMod(member,"insulatedengine",smods);
            smods -= 1;
            fitter.addExtraVents(member.getVariant());
            fitter.addExtraCaps(member.getVariant());
        }
    }
    protected int returnCost(String hullmod, HullSize size) {
        if(size == HullSize.FRIGATE) {
            return Global.getSettings().getHullModSpec(hullmod).getFrigateCost();
        } else if(size == HullSize.DESTROYER) {
            return Global.getSettings().getHullModSpec(hullmod).getDestroyerCost();
        } else if(size == HullSize.CRUISER) { 
            return Global.getSettings().getHullModSpec(hullmod).getCruiserCost();
        } else if(size == HullSize.CAPITAL_SHIP) {
            return Global.getSettings().getHullModSpec(hullmod).getCapitalCost();
        }
        return 0;
    }
    protected int addSMod(FleetMemberAPI member, String hullmod, int smods) {
        //this returns the hullmod cost unused!!!!!!!
        int unusedOP = 0;
        if(smods > 0) {
            if(member.getVariant().hasHullMod(hullmod)) {
                member.getVariant().removeMod(hullmod);
                unusedOP += returnCost(hullmod,member.getHullSpec().getHullSize());
            }
            member.getVariant().addPermaMod(hullmod,true);
        }
        return unusedOP;
    }
}